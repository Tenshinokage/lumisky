# LumiSky™ — Boutique Française

Copie complète de la boutique LumiSky entièrement traduite en français.

## Structure du projet

```
lumisky-fr/
├── index.html        ← Page principale (accueil + produit)
├── css/
│   └── style.css     ← Tous les styles
├── js/
│   └── main.js       ← Panier, FAQ, animations
└── README.md
```

## Fonctionnalités incluses

- ✅ Page d'accueil en français
- ✅ Page produit complète (variantes Starter / Premium)
- ✅ Panier latéral interactif
- ✅ Sélecteur de variante avec prix dynamique
- ✅ FAQ accordéon
- ✅ Avis clients
- ✅ 10 scènes traduites
- ✅ Sections "Parfait pour", "Contenu de la boîte"
- ✅ Animations au scroll
- ✅ Design responsive (mobile/tablette/desktop)
- ✅ Navigation sticky

## Comment utiliser

1. Ouvrez `index.html` dans votre navigateur
2. Pour intégrer dans Shopify, copiez le contenu HTML dans votre thème
3. Le CSS peut être ajouté dans `Assets` de votre thème Shopify
4. Le JS peut être ajouté dans `Assets` également

## Intégration Shopify

Pour utiliser dans Shopify :
- `index.html` → sections de votre thème (`.liquid`)
- `css/style.css` → `Assets/lumisky-fr.css`
- `js/main.js` → `Assets/lumisky-fr.js`

## Personnalisation

Modifiez les variables CSS dans `:root` dans `style.css` pour changer :
- `--accent` : couleur principale (violet par défaut)
- `--dark` : couleur de fond
- `--gold` : couleur des étoiles
